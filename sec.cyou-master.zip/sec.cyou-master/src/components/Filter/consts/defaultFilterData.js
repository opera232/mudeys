export const defaultFilterData = () => ({
    text: '',
    tags: {},
    chains: {},
});
