export const serializationStringForURI = (str) => str.replaceAll(' ', '_');
