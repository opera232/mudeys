import { createContext } from "react"

export const filterContext = createContext()
